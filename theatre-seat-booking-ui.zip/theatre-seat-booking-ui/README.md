# Theatre Seat Booking UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/aniketkudale/pen/oNXWzVY](https://codepen.io/aniketkudale/pen/oNXWzVY).

